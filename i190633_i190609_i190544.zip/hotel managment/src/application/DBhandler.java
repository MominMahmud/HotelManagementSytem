package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DBhandler {
	public void StoreDetails(int rl, int gid, int rnum, String rtype, String type, int days, int pam) {
		Configuration cfg = new Configuration();
		cfg.configure().addAnnotatedClass(Reservation.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		Reservation temp = new Reservation();
		// temppay.setPaymentId(1);
		temp.setRoomLocation(rl);
		temp.setGuestId(gid);
		temp.setRoomNum(rnum);
		temp.setRoomType(rtype);
		temp.setType(type);
		temp.setDays(days);
		temp.setPaymentAmount(pam);
		session.save(temp);
		trans.commit();

	}

	@SuppressWarnings("rawtypes")
	public ObservableList<Reservation> GetReservationList() {
		ObservableList<Reservation> templist = FXCollections.observableArrayList();
		Configuration cfg = new Configuration();
		cfg.configure().addAnnotatedClass(Reservation.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		List Reservation = session.createQuery("from Reservation").list();
		for (Iterator iterator = ((java.util.List) Reservation).iterator(); iterator.hasNext();) {
			Reservation b1 = (Reservation) iterator.next();
			templist.add(b1);
		}
		return templist;

	}

	public void DoPayment(int rid, int am) {

		Configuration cfg = new Configuration();
		cfg.configure().addAnnotatedClass(Payment.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		Payment temppay = new Payment();
		// temppay.setPaymentId(1);
		temppay.setReservation(rid);
		temppay.setAmount(am);
		session.save(temppay);
		trans.commit();
	}

	public void UpdateMantainanceFalse(int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		String sql = "update room set mantainance=? where number=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setBoolean(1, false);
		statement.setInt(2, id);
		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Updated Mantainance to False from table");
		con.close();
	}

	public void GetAvailableRooms() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		Statement temp1 = con.createStatement();
		ResultSet temp2 = temp1.executeQuery("select * from room");
		while (temp2.next()) {
			int id1 = temp2.getInt(1);
			int id2 = temp2.getInt(2);
			String n1 = temp2.getString(3);
			String id4 = temp2.getString(4);
			boolean id5 = temp2.getBoolean(5);
			boolean id6 = temp2.getBoolean(6);
			if (id5 == false && id6 == true) {
				System.out.println("The Room Number is: " + id1);
				System.out.println("The Floor is: " + id2);
				System.out.println("The Type is: " + n1);
				System.out.println("The Rate is: " + id4);
			}
		}

		con.close();

	}

	public int GetRoomviaID(int id) throws SQLException, ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		Statement temp1 = con.createStatement();
		ResultSet temp2 = temp1.executeQuery("select * from room");
		while (temp2.next()) {
			int id1 = temp2.getInt(1);
			int id2 = temp2.getInt(2);
			String n1 = temp2.getString(3);
			String id4 = temp2.getString(4);
			boolean id5 = temp2.getBoolean(5);
			boolean id6 = temp2.getBoolean(6);
			if (id1 == id) {
				System.out.println("The Room Number is: " + id1);
				System.out.println("The Floor is: " + id2);
				System.out.println("The Type is: " + n1);
				System.out.println("The Rate is: " + id4);
				if (id5 == true && id6 == false) {
					System.out.println("NotAvailable: ");
				} else {
					System.out.println("Availabale");
				}
				return 0;

			}

		}
		System.out.println("The Room Number does not exist: " + id);
		con.close();
		return 0;

	}

	public void AddRoom(int rnum, int loc, String type, int rate, boolean status, boolean man)
			throws SQLException, ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");

		String sql = "insert into room values (?,?,?,?,?,?)";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setInt(1, rnum);
		statement.setInt(2, loc);
		statement.setString(3, type);
		statement.setInt(4, rate);
		statement.setBoolean(5, status);
		statement.setBoolean(6, man);

		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Added value in table");
		con.close();

	}

	public void DeleteRoom(int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		String sql = "delete from room where number=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setInt(1, id);
		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Deleted value from table");
		con.close();
	}

	public void UpdateStatusTrue(int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		String sql = "update room set status=? where number=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setBoolean(1, true);
		statement.setInt(2, id);
		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Updated Status to Booked from table");
		con.close();
	}

	public void UpdateStatusFalse(int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		String sql = "update room set status=? where number=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setBoolean(1, false);
		statement.setInt(2, id);
		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Updated Status to Unbooked from table");
		con.close();
	}

	public void UpdateMantainanceTrue(int id) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel", "root", "");
		String sql = "update room set mantainance=? where number=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setBoolean(1, true);
		statement.setInt(2, id);
		int temp = statement.executeUpdate();
		if (temp > 0)
			System.out.println("Updated Mantianance to True from table");
		con.close();
	}
}
