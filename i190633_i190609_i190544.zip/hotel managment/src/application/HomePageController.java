package application;

import java.awt.Button;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HomePageController 
{
	  	@FXML
	    private Button BookRoom;
	  	private Stage primaryStageBookRoom;

	    @FXML
	    private Button CancelBooking;
	    private Stage primaryStageCancelBooking;

	    @FXML
	    private Button ChangeBooking;
	    private Stage primaryStageChangeBooking;

	    @FXML
	    private Button CheckIn;
	    private Stage primaryStageCheckIn;

	    @FXML
	    private Button CheckOut;
	    private Stage primaryStageCheckOut;

	    @FXML
	    private Button EditGuestDetails;
	    private Stage primaryStageEditGuestDetails;

	    @FXML
	    private Button UpdateRoomStatus;
	    private Stage primaryStageUpdateRoomStatus;

	    @FXML
	    private Button UpdateStock;
	    private Stage primaryStageUpdateStock;

	    @FXML
	    private Button ViewGuests;
	    private Stage primaryStageViewGuests;
	    
	   @FXML
	    void BookRoomButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageBookRoom= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/BookRoom.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageBookRoom.setScene(scene);
				primaryStageBookRoom.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void CancelBookingButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageCancelBooking= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/cancelBooking.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageCancelBooking.setScene(scene);
				primaryStageCancelBooking.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void ChangeBookingButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageChangeBooking= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/changeBooking.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageChangeBooking.setScene(scene);
				primaryStageChangeBooking.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void CheckInButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageCheckIn= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/CheckIn.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageCheckIn.setScene(scene);
				primaryStageCheckIn.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void CheckOutButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageCheckOut= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/CheckOut.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageCheckOut.setScene(scene);
				primaryStageCheckOut.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    
	    @FXML
	    void EditGuestDetailsButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageEditGuestDetails= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/editGuestDetails.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageEditGuestDetails.setScene(scene);
				primaryStageEditGuestDetails.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    
	    @FXML
	    void UpdateRoomStatusButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageUpdateRoomStatus= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/updateRoomStatus.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageUpdateRoomStatus.setScene(scene);
				primaryStageUpdateRoomStatus.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    
	    @FXML
	    void UpdateStockButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageUpdateStock= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/updateStock.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageUpdateStock.setScene(scene);
				primaryStageUpdateStock.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
	    
	    
	    @FXML
	    void ViewGuestsButtonClicked(ActionEvent event) 
	    {
	    	try
			{	
	    		primaryStageViewGuests= new Stage();
				Parent root=FXMLLoader.load(getClass().getResource("/application/viewGuest.fxml")); //importing document file
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStageViewGuests.setScene(scene);
				primaryStageViewGuests.show();
			} 
			catch(Exception e)
			{
				e.printStackTrace();
			}
	    }
}
