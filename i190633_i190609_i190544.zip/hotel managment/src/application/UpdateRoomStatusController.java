package application;

public class UpdateRoomStatusController {

}
