package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController{
    @FXML
    private Button login;
    private Stage primaryStagelogin;
   
    @FXML
    void LoginButtonClicked(ActionEvent event) 
    {
    	try
		{	
    		primaryStagelogin= new Stage();
    		Parent root=FXMLLoader.load(getClass().getResource("/application/HomePage.fxml")); //importing document file
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStagelogin.setScene(scene);
			primaryStagelogin.show();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    private TextField loginPassword;
    @FXML
    private TextField loginUsername;

  
}
